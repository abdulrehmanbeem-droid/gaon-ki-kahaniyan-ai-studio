گاؤں کی کہانیاں AI Studio — Android project + GitHub Actions APK build

اس پراجیکٹ میں:
- Android WebView wrapper (HTML prototype کو Android APK میں پیک کرتا ہے)
- کہانی سے scene-plan اور cartoon prompts
- Demo activation codes (صرف prototype، محفوظ/حقیقی ادائیگی نظام نہیں)
- GitHub Actions workflow (.github/workflows/android-build.yml) جو push یا دستی run پر debug APK بناتا ہے

APK بنانے کے لیے:
1. Repository میں اس ZIP کی تمام فائلیں اپلوڈ کریں (ZIP کے اندر موجود فولڈر کے contents، root پر)۔
2. GitHub پر Actions tab کھولیں۔ اگر workflow نظر آئے تو Android APK build منتخب کریں۔
3. Run workflow دبائیں۔ کامیاب build کے بعد run کے Artifacts حصے سے APK ZIP artifact ڈاؤن لوڈ کریں، extract کریں اور app-debug.apk انسٹال کریں۔

اہم حد:
یہ prototype AI سے حقیقی تصاویر، آواز، یا مکمل ویڈیو نہیں بناتا۔ یہ scene plan/prompts بناتا ہے۔ حقیقی video generation کے لیے AI API/backend اور ممکنہ خرچ درکار ہوگا۔ Demo activation codes کو paid access کے لیے استعمال نہ کریں۔
